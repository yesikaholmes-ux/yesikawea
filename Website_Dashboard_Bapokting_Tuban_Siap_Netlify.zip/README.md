# Dashboard Intelijen Harga Bapokting Kabupaten Tuban

Website statis HTML/CSS/JavaScript, dilengkapi Netlify Function untuk sinkronisasi Google Sheets.

## Upload ke Netlify (cara termudah)
1. Ekstrak ZIP ini. Jangan unggah `index.html` saja.
2. Masuk ke https://app.netlify.com/ dan buat site baru.
3. Untuk mengaktifkan fungsi sinkronisasi Google Sheets, **gunakan deploy melalui Git**:
   - Buat repositori GitHub baru.
   - Unggah seluruh isi folder ini ke root repositori, termasuk `netlify.toml` dan `netlify/functions/sheet.js`.
   - Pada Netlify pilih **Add new project → Import an existing project → GitHub**, pilih repositori.
   - Build command: kosong; Publish directory: `.`.
   - Deploy. Netlify otomatis mengaktifkan fungsi serverless.
4. Setelah website aktif, klik **Refresh Data** dan lihat status sinkronisasi.
5. Uji URL `https://NAMA-SITE.netlify.app/.netlify/functions/sheet` untuk melihat apakah proxy dapat mengambil CSV.

**Penting:** Metode drag-and-drop folder/ZIP di Netlify Drop hanya cocok untuk situs statis; fungsi `netlify/functions` mungkin tidak dideploy melalui metode ini. Untuk sinkronisasi otomatis gunakan Git deploy atau Netlify CLI (`netlify deploy --prod --dir=. --functions=netlify/functions`).

## Sumber data
Google Sheet publik:
https://docs.google.com/spreadsheets/d/1m3e9cYb13aMrSNnj6pdUqgZe2iSGxKVywbPQUOUzhZQ/edit?gid=74546651

CSV yang didukung menggunakan kolom `Tanggal`, `Pasar`, `Komoditas`, `Harga`; `Satuan` opsional. Kolom dapat berada setelah beberapa baris judul, dan pemisah koma atau titik koma didukung. Jika sumber berbentuk matriks lebar dengan format lain, data harus dinormalisasi terlebih dahulu.

## Batasan
- Data bawaan adalah snapshot historis dan akan ditampilkan jika sinkronisasi gagal.
- Input manual disimpan di browser perangkat (localStorage), **tidak** ditulis kembali ke Google Sheets dan tidak dibagikan antarpengguna.
- Sinkronisasi otomatis 5/10/15 menit berjalan saat halaman website terbuka; bukan pekerjaan latar belakang 24 jam.
- Pengambilan Google Sheets memerlukan izin baca publik. Berbagi sebagai Viewer tidak selalu cukup bila Google menolak endpoint CSV.
- Ekspor Excel memerlukan koneksi ke pustaka SheetJS CDN. Fallback ekspor CSV tersedia.
- HET/HAP merupakan nilai acuan yang dibawa dari dashboard lama; verifikasi ulang sebelum digunakan untuk keputusan resmi.
