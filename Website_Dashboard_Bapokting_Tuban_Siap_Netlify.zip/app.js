
'use strict';
const $=id=>document.getElementById(id), base=JSON.parse($('dataset').textContent), HET=JSON.parse($('reference').textContent);let rows=base.slice(),history=[];const markets=['Pasar Baru','Pasar Jatirogo','Pasar Karangagung'];
const uniq=a=>[...new Set(a)].sort((a,b)=>String(a).localeCompare(String(b),'id'));const mean=a=>a.length?a.reduce((s,v)=>s+v,0)/a.length:null;const median=a=>{if(!a.length)return null;let b=a.slice().sort((x,y)=>x-y);return b.length%2?b[(b.length-1)/2]:(b[b.length/2-1]+b[b.length/2])/2};const rp=v=>v==null?'—':'Rp '+Math.round(v).toLocaleString('id-ID');const pct=v=>v==null?'—':v.toFixed(2)+'%';const key=r=>[r.tanggal,r.pasar,r.komoditas,r.satuan].join('|');const safe=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function setOptions(id,vals){let e=$(id),old=e.value;e.innerHTML='<option value="">Semua</option>'+vals.map(x=>'<option value="'+safe(x)+'">'+safe(x)+'</option>').join('');e.value=vals.includes(old)?old:''}
function populate(){setOptions('market',uniq(rows.map(r=>r.pasar)));setOptions('commodity',uniq(rows.map(r=>r.komoditas)));setOptions('unit',uniq(rows.map(r=>r.satuan)));[['markets','pasar'],['commodities','komoditas'],['units','satuan']].forEach(([id,k])=>$(id).innerHTML=uniq(rows.map(r=>r[k])).map(x=>'<option value="'+safe(x)+'"></option>').join(''))}
function filter(){return rows.filter(r=>(!$('from').value||r.tanggal>=$('from').value)&&(!$('to').value||r.tanggal<=$('to').value)&&(!$('market').value||r.pasar===$('market').value)&&(!$('commodity').value||r.komoditas===$('commodity').value)&&(!$('unit').value||r.satuan===$('unit').value))}
function groups(a,fn){let o=new Map();a.forEach(r=>{let k=fn(r);if(!o.has(k))o.set(k,[]);o.get(k).push(r)});return o}
function latest(a){if(!a.length)return [];let date=a.reduce((s,r)=>r.tanggal>s?r.tanggal:s,'');return a.filter(r=>r.tanggal===date)}
function latestByMarket(a){let out=[];groups(a,r=>r.pasar).forEach(arr=>{let d=latest(arr);if(d.length)out.push({pasar:d[0].pasar,harga:mean(d.map(r=>r.harga)),tanggal:d[0].tanggal})});return out}
function referenceStatus(price,het){if(!het)return ['Tidak ada acuan',''];let diff=(price-het)/het*100;return diff>0.001?['Di atas HET/HAP','bad']:diff<-.001?['Di bawah HET/HAP','ok']:['Sesuai HET/HAP','mid']}
function svgBar(id,items,{percent=false,color='#2869b0'}={}){let el=$(id);if(!items.length){el.innerHTML='<div class="empty">Tidak ada data sesuai filter</div>';return}let W=650,H=300,L=58,R=18,T=16,B=92;let max=Math.max(1,...items.map(d=>Math.abs(d.v)));let min=percent?Math.min(0,...items.map(d=>d.v)):0;let upper=Math.max(0,...items.map(d=>d.v));if(!upper&&!min)upper=1;let y=v=>T+(upper-v)/(upper-min)*(H-T-B);let n=items.length,step=(W-L-R)/n,bw=Math.max(5,step*.62);let labels=items.map((d,i)=>{let x=L+i*step+step/2;let label=d.name.length>17?d.name.slice(0,16)+'…':d.name;return `<text x="${x}" y="${H-B+15}" font-size="10" text-anchor="end" transform="rotate(-35 ${x} ${H-B+15})" fill="#52667c">${safe(label)}</text>`}).join('');let bars=items.map((d,i)=>{let x=L+i*step+(step-bw)/2,y0=y(0),yv=y(d.v);return `<rect x="${x}" y="${Math.min(y0,yv)}" width="${bw}" height="${Math.max(1,Math.abs(y0-yv))}" fill="${d.v>0&&percent?'#d46a54':color}" rx="3"><title>${safe(d.name)}: ${percent?pct(d.v):rp(d.v)}</title></rect>`}).join('');el.innerHTML=`<svg viewBox="0 0 ${W} ${H}" role="img"><line x1="${L}" x2="${W-R}" y1="${y(0)}" y2="${y(0)}" stroke="#91a3b7"/><line x1="${L}" x2="${L}" y1="${T}" y2="${H-B}" stroke="#d5e1ea"/><text x="${L-7}" y="${T+10}" text-anchor="end" font-size="11" fill="#637487">${percent?pct(upper):rp(upper)}</text><text x="${L-7}" y="${H-B}" text-anchor="end" font-size="11" fill="#637487">${percent?pct(min):rp(min)}</text>${bars}${labels}</svg>`}
function svgLine(id,series){let el=$(id);if(!series.length){el.innerHTML='<div class="empty">Tidak cukup bulan untuk menghitung perubahan</div>';return}let W=650,H=300,L=60,R=20,T=22,B=50;let vals=series.map(x=>x.v),min=Math.min(0,...vals),max=Math.max(0,...vals);if(min===max){min-=1;max+=1}let x=i=>L+i*(W-L-R)/Math.max(1,series.length-1),y=v=>T+(max-v)/(max-min)*(H-T-B);let path=series.map((d,i)=>(i?'L':'M')+x(i)+','+y(d.v)).join(' ');el.innerHTML=`<svg viewBox="0 0 ${W} ${H}" role="img"><line x1="${L}" x2="${W-R}" y1="${y(0)}" y2="${y(0)}" stroke="#a9b9c8"/><path d="${path}" fill="none" stroke="#18877e" stroke-width="3"/>${series.map((d,i)=>`<circle cx="${x(i)}" cy="${y(d.v)}" r="5" fill="#18877e"><title>${safe(d.month)}: ${pct(d.v)}</title></circle><text x="${x(i)}" y="${H-B+20}" text-anchor="middle" font-size="11" fill="#52667c">${safe(d.month.slice(5))}</text>`).join('')}<text x="${L-7}" y="${T+8}" text-anchor="end" font-size="11">${pct(max)}</text><text x="${L-7}" y="${H-B}" text-anchor="end" font-size="11">${pct(min)}</text></svg>`}
function compute(a){let comGroups=groups(a,r=>r.komoditas+'|'+r.satuan),report=[];comGroups.forEach((arr,k)=>{let [name,unit]=k.split('|'),last=latest(arr),per=latestByMarket(arr),p=mean(last.map(r=>r.harga)),h=HET[name]||null;let values=per.map(x=>x.harga),spread=values.length>1?(Math.max(...values)-Math.min(...values))/mean(values)*100:null;let byMonth=groups(arr,r=>r.tanggal.slice(0,7)),months=[...byMonth.keys()].sort(),monthly=months.map(m=>({month:m,avg:mean(byMonth.get(m).map(r=>r.harga))}));let changes=monthly.slice(1).map((d,i)=>({month:d.month,v:(d.avg-monthly[i].avg)/monthly[i].avg*100}));report.push({name,unit,last,per,price:p,het:h,spread,monthly,changes,latestDate:last[0]?.tanggal||''})});return report.sort((x,y)=>x.name.localeCompare(y.name,'id'))}
function selectCatalogCommodity(i){let c=(window.catalogCommodities||[])[i];if(!c)return;$('commodity').value=c;render();$('catalog').scrollIntoView({behavior:'smooth',block:'start'});}
function render(){let a=filter(),reports=compute(a),coms=uniq(a.map(r=>r.komoditas)),ms=uniq(a.map(r=>r.pasar)),single=reports.length===1?reports[0]:null;
$('kCom').textContent=coms.length;$('kMarket').textContent=ms.length+' pasar · '+a.length.toLocaleString('id-ID')+' catatan harga';$('kAvg').textContent=single?rp(single.price):'Pilih komoditas';$('kAvgNote').textContent=single?'Harga rata-rata tanggal '+single.latestDate+' / '+single.unit:'Tidak menghitung rata-rata lintas komoditas';
let maxSpread=reports.filter(x=>x.spread!==null).sort((a,b)=>b.spread-a.spread)[0];$('kSpread').textContent=maxSpread?pct(maxSpread.spread):'—';$('kSpreadNote').textContent=maxSpread?maxSpread.name+' · '+maxSpread.latestDate:'Perlu ≥2 pasar';
let allChanges=reports.flatMap(r=>r.changes.map(x=>Math.abs(x.v)));let stability=allChanges.length?Math.max(0,100-Math.min(100,median(allChanges)*10)):null;$('kStab').textContent=stability===null?'—':stability.toFixed(1)+'/100';$('kStabNote').textContent='Berbasis median perubahan bulanan';
$('catalog').innerHTML='<div class="commodity-hero"><div><div class="hero-eyebrow">CAKUPAN PEMANTAUAN</div><div class="hero-number">'+coms.length+' <small>komoditas aktif</small></div><div class="hero-sub">Periode '+(a.length?uniq(a.map(r=>r.tanggal))[0]:'—')+' — '+(a.length?uniq(a.map(r=>r.tanggal)).slice(-1)[0]:'—')+'</div></div><div class="hero-icon">◈</div></div><div class="commodity-stats"><div><b>'+ms.length+'</b><span>Pasar terpantau</span></div><div><b>'+uniq(a.map(r=>r.satuan)).length+'</b><span>Jenis satuan</span></div><div><b>'+a.length.toLocaleString('id-ID')+'</b><span>Catatan harga</span></div></div><div class="commodity-heading"><strong>Daftar komoditas</strong><small>Klik untuk melihat analisisnya</small></div><div class="commodity-list">'+coms.map((c,i)=>{let z=a.filter(r=>r.komoditas===c),u=uniq(z.map(r=>r.satuan)).join(' / '),pm=uniq(z.map(r=>r.pasar)).length;return '<button type="button" class="commodity-item" onclick="selectCatalogCommodity('+i+')"><span class="commodity-index">'+String(i+1).padStart(2,'0')+'</span><span class="commodity-name">'+safe(c)+'<small>'+safe(u)+' · '+pm+' pasar</small></span><span class="commodity-arrow">↗</span></button>'}).join('')+'</div>';window.catalogCommodities=coms;
let withHet=reports.filter(r=>r.het&&r.price!==null),above=withHet.filter(r=>r.price>r.het),below=withHet.filter(r=>r.price<r.het),equal=withHet.length-above.length-below.length;
$('hetSummary').innerHTML=`<div class="kpis" style="grid-template-columns:repeat(3,1fr);margin-top:12px"><div class="kpi"><small>Di atas acuan</small><strong style="color:#b73538">${above.length}</strong><span>Komoditas</span></div><div class="kpi"><small>Sesuai</small><strong>${equal}</strong><span>Komoditas</span></div><div class="kpi"><small>Di bawah</small><strong style="color:#0d877e">${below.length}</strong><span>Komoditas</span></div></div><div class="note">${withHet.length} dari ${reports.length} komoditas/satuan memiliki HET/HAP. Evaluasi berdasarkan rata-rata harga pada tanggal terakhir masing-masing komoditas.</div>`;
window.hetReports=reports;renderHetInteractive();
let high=above.slice().sort((a,b)=>(b.price/b.het)-(a.price/a.het))[0];
let low=below.slice().sort((a,b)=>(a.price/a.het)-(b.price/b.het))[0];
$('hetInsights').innerHTML='<div class="het-insight-grid"><div><small>Cakupan referensi</small><b>'+withHet.length+' / '+reports.length+'</b><span>Komoditas/satuan dengan acuan</span></div><div><small>Deviasi tertinggi di atas acuan</small><b class="het-red">'+(high?pct((high.price/high.het-1)*100):'—')+'</b><span>'+(high?safe(high.name):'Tidak ada')+'</span></div><div><small>Deviasi terendah dari acuan</small><b class="het-green">'+(low?pct((low.price/low.het-1)*100):'—')+'</b><span>'+(low?safe(low.name):'Tidak ada')+'</span></div></div>';
let monthSeries=[];if(single)monthSeries=single.changes;else{let by=groups(reports.flatMap(r=>r.changes),r=>r.month);monthSeries=[...by].sort(([a],[b])=>a.localeCompare(b)).map(([month,v])=>({month,v:median(v.map(x=>x.v))}))}svgLine('monthly',monthSeries);
let hetBars=[];if(single&&single.het)hetBars=single.per.map(p=>({name:p.pasar,v:(p.harga-single.het)/single.het*100}));else hetBars=withHet.map(r=>({name:r.name,v:(r.price-r.het)/r.het*100})).sort((a,b)=>b.v-a.v).slice(0,12);svgBar('hetChart',hetBars,{percent:true});svgBar('spreadChart',reports.filter(r=>r.spread!==null).sort((a,b)=>b.spread-a.spread).slice(0,12).map(r=>({name:r.name,v:r.spread})),{percent:true,color:'#178e86'});
let alerts=[];reports.filter(r=>r.het&&r.price>r.het).sort((a,b)=>(b.price/b.het)-(a.price/a.het)).slice(0,5).forEach(r=>alerts.push(`${r.name}: rata-rata ${rp(r.price)} di atas HET/HAP ${rp(r.het)} (${pct((r.price/r.het-1)*100)}).`));reports.filter(r=>r.spread>=10).sort((a,b)=>b.spread-a.spread).slice(0,4).forEach(r=>alerts.push(`${r.name}: disparitas antar pasar ${pct(r.spread)} pada tanggal terbaru.`));$('alerts').innerHTML=alerts.length?alerts.map(x=>'<div class="alert">'+safe(x)+'</div>').join(''):'<div class="note">Tidak ditemukan pelanggaran acuan atau disparitas ≥10% pada cakupan filter.</div>';
let h='<tr><th>Komoditas</th><th>Satuan</th>'+markets.map(x=>'<th>'+x+'</th>').join('')+'<th>Rata-rata terakhir</th><th>Disparitas</th><th>HET/HAP</th><th>Evaluasi</th></tr>';$('matrix').querySelector('thead').innerHTML=h;$('matrix').querySelector('tbody').innerHTML=reports.map(r=>{let [label,cl]=referenceStatus(r.price,r.het);return '<tr><td><button class="alt" style="padding:5px" data-com="'+safe(r.name)+'">'+safe(r.name)+'</button></td><td>'+safe(r.unit)+'</td>'+markets.map(m=>'<td>'+rp(r.per.find(x=>x.pasar===m)?.harga)+'</td>').join('')+'<td>'+rp(r.price)+'</td><td>'+pct(r.spread)+'</td><td>'+rp(r.het)+'</td><td><span class="pill '+cl+'">'+label+'</span></td></tr>'}).join('');
$('hetTable').querySelector('tbody').innerHTML=reports.map(r=>{let [label,cl]=referenceStatus(r.price,r.het),diff=r.het?r.price-r.het:null;return '<tr><td>'+safe(r.name)+'</td><td>'+safe(r.unit)+'</td><td>'+rp(r.het)+'</td><td>'+rp(r.price)+'</td><td>'+rp(diff)+'</td><td>'+pct(r.het?diff/r.het*100:null)+'</td><td><span class="pill '+cl+'">'+label+'</span></td></tr>'}).join('');
$('detailCaption').textContent='Menampilkan 400 catatan terbaru dari '+a.length.toLocaleString('id-ID')+' catatan sesuai filter. Ekspor Excel mencakup seluruh catatan terfilter.';$('detail').querySelector('tbody').innerHTML=a.slice().sort((x,y)=>y.tanggal.localeCompare(x.tanggal)).slice(0,400).map(r=>{let [label,cl]=referenceStatus(r.harga,HET[r.komoditas]);return '<tr><td>'+r.tanggal+'</td><td>'+safe(r.pasar)+'</td><td>'+safe(r.komoditas)+'</td><td>'+safe(r.satuan)+'</td><td>'+rp(r.harga)+'</td><td>'+rp(HET[r.komoditas])+'</td><td><span class="pill '+cl+'">'+label+'</span></td></tr>'}).join('');
$('matrix').querySelectorAll('[data-com]').forEach(b=>b.addEventListener('click',()=>{$('commodity').value=b.dataset.com;render();$('detail').scrollIntoView({behavior:'smooth',block:'start'})}));renderDaily();}

function renderDaily(){
 const all=filter(), dEl=$('dailyDate'),mEl=$('dailyMarket'),cEl=$('dailyCommodity');
 const dates=uniq(all.map(r=>r.tanggal));
 const dateDefault=dates[dates.length-1]||'';
 if(!dEl.value)dEl.value=dateDefault;
 const date=dEl.value;
 const markets=uniq(all.map(r=>r.pasar)),commodities=uniq(all.map(r=>r.komoditas));
 const prevMarket=mEl.value,prevCom=cEl.value;
 mEl.innerHTML='<option value="">Semua pasar</option>'+markets.map(x=>'<option value="'+safe(x)+'">'+safe(x)+'</option>').join('');
 cEl.innerHTML='<option value="">Semua komoditas</option>'+commodities.map(x=>'<option value="'+safe(x)+'">'+safe(x)+'</option>').join('');
 mEl.value=markets.includes(prevMarket)?prevMarket:'';cEl.value=commodities.includes(prevCom)?prevCom:'';
 const market=mEl.value,commodity=cEl.value;
 const base=all.filter(r=>(!market||r.pasar===market)&&(!commodity||r.komoditas===commodity));
 const today=base.filter(r=>r.tanggal===date);
 const keys=uniq(today.map(r=>r.komoditas+'|'+r.satuan));
 $('dailyCount').textContent=keys.length;
 const previous=(r)=>{let prior=all.filter(x=>x.tanggal<r.tanggal&&x.pasar===r.pasar&&x.komoditas===r.komoditas&&x.satuan===r.satuan).sort((a,b)=>b.tanggal.localeCompare(a.tanggal));return prior[0]||null};
 let up=0,down=0;const movements=new Map();
 today.forEach(r=>{let p=previous(r);let delta=p&&p.harga>0?(r.harga/p.harga-1)*100:null;movements.set(r,delta);if(delta!==null){if(delta>0)up++;if(delta<0)down++}});
 $('dailyUp').textContent=up;$('dailyDown').textContent=down;
 const sorted=[...today].sort((a,b)=>a.komoditas.localeCompare(b.komoditas,'id')||a.pasar.localeCompare(b.pasar,'id'));
 $('dailyRows').innerHTML=sorted.length?sorted.map(r=>{let delta=movements.get(r);return '<tr><td>'+safe(r.pasar)+'</td><td>'+safe(r.komoditas)+'</td><td>'+safe(r.satuan)+'</td><td><b>'+rp(r.harga)+'</b></td><td style="color:'+(delta>0?'#b73538':delta<0?'#0d877e':'#6b7c8e')+'">'+(delta===null?'—':(delta>0?'+':'')+delta.toFixed(2)+'%')+'</td></tr>'}).join(''):'<tr><td colspan="5">Tidak ada harga tercatat pada tanggal ini untuk pilihan pasar dan komoditas. Silakan pilih tanggal lain.</td></tr>';
 const period=Number($('dailyRange').value),end=date,start=period?new Date(new Date(date+'T12:00:00').getTime()-(period-1)*86400000).toISOString().slice(0,10):'';
 const timeline=base.filter(r=>r.tanggal<=end&&(!start||r.tanggal>=start));
 const groupsMap=new Map();timeline.forEach(r=>{let k=r.komoditas+'|'+r.satuan+'|'+r.pasar;if(!groupsMap.has(k))groupsMap.set(k,[]);groupsMap.get(k).push(r)});
 // When all commodities are selected, draw the selected day's first commodity only; table still shows all.
 let chosen=commodity;if(!chosen){chosen=sorted[0]?.komoditas||timeline[0]?.komoditas||''}
 let series=[...groupsMap.values()].filter(arr=>arr[0].komoditas===chosen);
 const colors=['#2869b0','#0d877e','#e09b39','#995ab9'];
 series=series.map((arr,i)=>{let map=new Map();arr.forEach(r=>map.set(r.tanggal,r.harga));return{name:arr[0].pasar,commodity:arr[0].komoditas,unit:arr[0].satuan,color:colors[i%colors.length],map}});
 const allDates=uniq(timeline.filter(r=>r.komoditas===chosen).map(r=>r.tanggal));
 $('dailyTitle').textContent=chosen?'Tren Harian: '+chosen:'Tren Harga Harian';
 $('dailyPeriod').textContent=(start||allDates[0]||'—')+' s.d. '+date;
 if(!series.length||!allDates.length){$('dailyChart').innerHTML='<p class="hint" style="padding:40px;text-align:center">Tidak ada data tren untuk kombinasi tanggal, pasar, dan komoditas ini.</p>';$('dailyLegend').innerHTML='';return}
 const values=series.flatMap(s=>[...s.map.values()]);let min=Math.min(...values),max=Math.max(...values),pad=Math.max(200,(max-min)*.15),lo=Math.max(0,min-pad),hi=max+pad;
 const W=900,H=330,L=92,R=24,T=22,B=46,ww=W-L-R,hh=H-T-B;
 const x=i=>L+(allDates.length===1?ww/2:i*ww/(allDates.length-1)),y=v=>T+hh-(v-lo)/(hi-lo)*hh;
 let svg='<svg viewBox="0 0 '+W+' '+H+'" role="img" aria-label="Grafik harga harian per pasar">';
 for(let i=0;i<5;i++){let v=lo+(hi-lo)*i/4,yy=y(v);svg+='<line x1="'+L+'" y1="'+yy+'" x2="'+(W-R)+'" y2="'+yy+'" stroke="#e7edf4" stroke-dasharray="4 4"/><text x="'+(L-8)+'" y="'+(yy+4)+'" text-anchor="end" fill="#74808d" font-size="12">'+Math.round(v).toLocaleString('id-ID')+'</text>'}
 let step=Math.max(1,Math.ceil(allDates.length/7));allDates.forEach((d,i)=>{if(i%step===0||i===allDates.length-1)svg+='<text x="'+x(i)+'" y="'+(H-14)+'" text-anchor="middle" fill="#74808d" font-size="12">'+d.slice(8)+'/'+d.slice(5,7)+'</text>'});
 series.forEach((s,si)=>{let points=[];allDates.forEach((d,i)=>{let v=s.map.get(d);if(v!==undefined)points.push(x(i)+','+y(v))});if(points.length>1)svg+='<polyline points="'+points.join(' ')+'" fill="none" stroke="'+s.color+'" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>';
 allDates.forEach((d,i)=>{let v=s.map.get(d);if(v!==undefined)svg+='<circle cx="'+x(i)+'" cy="'+y(v)+'" r="4.7" fill="'+s.color+'" stroke="white" stroke-width="1.5" class="daily-point" data-series="'+si+'" data-index="'+i+'"/>'})});
 svg+='</svg>';$('dailyChart').innerHTML=svg;
 $('dailyLegend').innerHTML=series.map(s=>'<span><i style="background:'+s.color+'"></i>'+safe(s.name)+' · '+safe(s.unit)+'</span>').join('');
 $('dailyChart').querySelectorAll('.daily-point').forEach(el=>{el.addEventListener('mouseenter',()=>{let s=series[Number(el.dataset.series)],d=allDates[Number(el.dataset.index)];$('dailyTooltip').textContent=d+' · '+s.name+' · '+s.commodity+' · '+rp(s.map.get(d))+'/'+s.unit;el.setAttribute('r','7')});el.addEventListener('mouseleave',()=>el.setAttribute('r','4.7'))});
}

function csv(records){let cols=['Tanggal','Pasar','Komoditas','Satuan','Harga (Rp)'];return [cols,...records.map(r=>[r.tanggal,r.pasar,r.komoditas,r.satuan,r.harga])].map(row=>row.map(v=>'"'+String(v).replaceAll('"','""')+'"').join(',')).join('\r\n')}
function download(content,name,type='text/csv;charset=utf-8'){let blob=new Blob([content],{type}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000)}
function saveState(){try{localStorage.setItem('tuban_harga_dashboard_v3',JSON.stringify(rows.slice(base.length)))}catch(e){$('message').textContent='Penyimpanan lokal browser penuh; ekspor data sebelum menutup.'}}
function log(action,count,note){history.unshift({time:new Date().toLocaleString('id-ID'),action,count,note});$('history').innerHTML=history.map(r=>`<tr><td>${safe(r.time)}</td><td>${safe(r.action)}</td><td>${r.count}</td><td>${safe(r.note)}</td></tr>`).join('')}
function addRecords(items,action){let keys=new Set(rows.map(key)),newRows=[];for(let r of items){if(!r.tanggal||!r.pasar||!r.komoditas||!r.satuan||!(r.harga>0)||!/^\d{4}-\d\d-\d\d$/.test(r.tanggal))continue;let k=key(r);if(!keys.has(k)){keys.add(k);newRows.push(r)}}rows.push(...newRows);saveState();populate();render();log(action,newRows.length,`${items.length-newRows.length} duplikat / tidak valid dilewati`);$('message').textContent=`${newRows.length} data baru berhasil ditambahkan.`}
function parseDate(v){if(v instanceof Date)return v.toISOString().slice(0,10);if(typeof v==='number')return new Date(Date.UTC(1899,11,30)+v*86400000).toISOString().slice(0,10);let s=String(v).trim();if(/^\d{4}-\d\d-\d\d$/.test(s))return s;let m=s.match(/^(\d{1,2})[\/.-](\d{1,2})[\/.-](\d{4})$/);return m?`${m[3]}-${m[2].padStart(2,'0')}-${m[1].padStart(2,'0')}`:''}
function normalizeObjects(items){return items.map(o=>{let low={};Object.entries(o).forEach(([k,v])=>low[k.trim().toLowerCase()]=v);let g=(...names)=>{for(let n of names)if(low[n]!==undefined)return low[n];return ''};return {tanggal:parseDate(g('tanggal','date')),pasar:String(g('pasar','market')).trim(),komoditas:String(g('komoditas','nama komoditas','nama bahan pokok')).trim().replace(/^-\s*/,''),satuan:String(g('satuan','unit')).trim(),harga:(()=>{let v=g('harga (rp)','harga','price');if(typeof v==='number')return v;let t=String(v).replace(/[^0-9.,-]/g,'');return Number(t.includes(',')?t.replaceAll('.','').replace(',','.'):t.replace(/\.(?=\d{3}(?:\.|$))/g,''))})()}})}
function parseCSV(text){let result=[],row=[],field='',quoted=false;for(let i=0;i<text.length;i++){let c=text[i];if(c==='"'){if(quoted&&text[i+1]==='"'){field+='"';i++}else quoted=!quoted}else if(c===','&&!quoted){row.push(field);field=''}else if((c==='\n'||c==='\r')&&!quoted){if(c==='\r'&&text[i+1]==='\n')i++;row.push(field);if(row.some(v=>v.trim()))result.push(row);row=[];field=''}else field+=c}row.push(field);if(row.some(v=>v.trim()))result.push(row);let head=result.shift()||[];return result.map(r=>Object.fromEntries(head.map((h,i)=>[h,r[i]||''])))}
$('apply').onclick=render;$('reset').onclick=()=>{['from','to','market','commodity','unit'].forEach(id=>$(id).value='');render()};$('print').onclick=()=>window.print();$('save').onclick=()=>{let r={tanggal:$('fDate').value,pasar:$('fMarket').value.trim(),komoditas:$('fCom').value.trim(),satuan:$('fUnit').value.trim(),harga:Number($('fPrice').value)};if(!r.tanggal||!r.pasar||!r.komoditas||!r.satuan||r.harga<=0){$('message').textContent='Semua kolom wajib diisi dengan harga positif.';return}addRecords([r],'Input manual')};$('downloadTemplate').onclick=()=>download('\ufeff'+csv([]),'Template_Harga_Harian_Tuban.csv');$('export').onclick=()=>{let a=filter();if(window.XLSX){let w=XLSX.utils.book_new();XLSX.utils.book_append_sheet(w,XLSX.utils.json_to_sheet(a.map(r=>({'Tanggal':r.tanggal,'Pasar':r.pasar,'Komoditas':r.komoditas,'Satuan':r.satuan,'Harga (Rp)':r.harga}))),'Data Harga');XLSX.writeFile(w,'Harga_Bapokting_Tuban.xlsx')}else download('\ufeff'+csv(a),'Harga_Bapokting_Tuban.csv')};
$('import').onclick=async()=>{let f=$('upload').files[0];if(!f){$('message').textContent='Pilih file dahulu.';return}try{let items;if(/\.csv$/i.test(f.name))items=parseCSV(await f.text());else{if(!window.XLSX)throw new Error('Untuk Excel, perlu koneksi internet memuat pustaka XLSX. Gunakan CSV jika offline.');let w=XLSX.read(await f.arrayBuffer(),{type:'array',cellDates:true});items=XLSX.utils.sheet_to_json(w.Sheets[w.SheetNames[0]],{defval:''})}addRecords(normalizeObjects(items),'Impor '+f.name)}catch(e){$('message').textContent='Impor gagal: '+e.message}};
function renderHetInteractive(){
 const input=document.getElementById('hetSearch'),sel=document.getElementById('hetStatus'),order=document.getElementById('hetSort'),target=document.getElementById('hetInteractiveCards');
 if(!input||!target)return;
 let a=(window.hetReports||[]).filter(r=>r.name.toLowerCase().includes(input.value.toLowerCase().trim()));
 let status=r=>!r.het||r.price===null?'missing':r.price>r.het?'above':r.price<r.het?'below':'equal';
 if(sel.value!=='all')a=a.filter(r=>status(r)===sel.value);
 if(order.value==='name')a.sort((x,y)=>x.name.localeCompare(y.name));
 else if(order.value==='price')a.sort((x,y)=>(y.price||0)-(x.price||0));
 else a.sort((x,y)=>((y.het&&y.price)?(y.price/y.het-1):-999)-((x.het&&x.price)?(x.price/x.het-1):-999));
 document.getElementById('hetShown').textContent=a.length+' komoditas ditampilkan';
 target.innerHTML=a.map(r=>{let st=status(r),delta=r.het&&r.price!==null?(r.price/r.het-1)*100:null,labels={above:'Di atas acuan',below:'Di bawah acuan',equal:'Sesuai acuan',missing:'Tanpa acuan'};
 return '<button type="button" class="het-card" data-com="'+encodeURIComponent(r.name)+'"><span class="het-card-top"><strong>'+safe(r.name)+'</strong><span class="het-pill '+st+'">'+labels[st]+'</span></span><span class="het-card-prices"><span>Harga pasar <b>'+rp(r.price)+'</b></span><span>HET/HAP <b>'+rp(r.het)+'</b></span></span><span class="het-card-bottom"><span>'+safe(r.unit)+'</span><b class="'+(delta>0?'het-red':'het-green')+'">'+(delta===null?'Tidak tersedia':pct(delta))+'</b></span></button>'}).join('')||'<p class="note">Tidak ada komoditas yang sesuai pencarian.</p>';
 target.querySelectorAll('.het-card').forEach(el=>el.addEventListener('click',()=>{let c=decodeURIComponent(el.dataset.com);document.getElementById('commodity').value=c;render();document.getElementById('hetEvaluation').scrollIntoView({behavior:'smooth',block:'start'});}));
}
['hetSearch','hetStatus','hetSort'].forEach(id=>document.getElementById(id).addEventListener(id==='hetSearch'?'input':'change',renderHetInteractive));
document.getElementById('hetReset').addEventListener('click',()=>{document.getElementById('hetSearch').value='';document.getElementById('hetStatus').value='all';document.getElementById('hetSort').value='deviation';renderHetInteractive()});

try{let stored=JSON.parse(localStorage.getItem('tuban_harga_dashboard_v3')||'[]');if(Array.isArray(stored))rows.push(...stored)}catch(e){}populate();let ds=uniq(rows.map(r=>r.tanggal));$('from').value=ds[0]||'';$('to').value=ds[ds.length-1]||'';$('fDate').value=new Date().toISOString().slice(0,10);render();

// Google Sheets CSV synchronization. Browser must have network access and allow CORS.
const SHEET_CSV='https://docs.google.com/spreadsheets/d/1m3e9cYb13aMrSNnj6pdUqgZe2iSGxKVywbPQUOUzhZQ/gviz/tq?tqx=out%3Acsv&gid=74546651';
const SHEET_CSV_FALLBACK='https://docs.google.com/spreadsheets/d/1m3e9cYb13aMrSNnj6pdUqgZe2iSGxKVywbPQUOUzhZQ/export?format=csv&gid=74546651';
const SYNC_CACHE_KEY='tuban_google_sheets_cache_v1';
let syncTimer=null, syncBusy=false;
function syncStatus(message,error=false){
 $('syncStatus').textContent=message;
 $('syncStatus').classList.toggle('sync-error',error);
}
function mergeWithLocal(incoming){
 // The sheet is authoritative for matching date/market/commodity/unit keys.
 const merged=new Map();
 base.forEach(r=>merged.set(key(r),r));
 try{
  const manual=JSON.parse(localStorage.getItem('tuban_harga_dashboard_v3')||'[]');
  if(Array.isArray(manual))manual.forEach(r=>{if(r&&r.tanggal)merged.set(key(r),r)});
 }catch(e){}
 incoming.forEach(r=>merged.set(key(r),r));
 rows=Array.from(merged.values()).sort((a,b)=>a.tanggal.localeCompare(b.tanggal));
 populate();
 const dates=uniq(rows.map(r=>r.tanggal));
 if(dates.length){
  $('from').value=dates[0];$('to').value=dates[dates.length-1];
  if($('dailyDate'))$('dailyDate').value=dates[dates.length-1];
 }
 render();
 $('syncCount').textContent='Total: '+rows.length.toLocaleString('id-ID')+' catatan harga';
 $('syncLatest').textContent='Tanggal data terbaru: '+(dates.at(-1)||'—');
}

function validateSheet(csvText){
 const clean=csvText.replace(/^\uFEFF/,'');
 const matrix=parseCSVMatrix(clean);
 if(matrix.length<2)throw Error('CSV kosong atau hanya memiliki judul.');
 const norm=x=>String(x??'').trim().toLowerCase().replace(/\s+/g,' ').replace(/\([^)]*\)/g,'').trim();
 const aliases={
  tanggal:['tanggal','date','tgl','tanggal pantau'],
  pasar:['pasar','market','nama pasar'],
  komoditas:['komoditas','nama komoditas','nama bahan pokok','bahan pokok','jenis komoditas'],
  satuan:['satuan','unit'],
  harga:['harga','harga rp','harga jual','harga konsumen','price']
 };
 let headerIndex=-1, mapping=null;
 for(let i=0;i<Math.min(matrix.length,25);i++){
  const heads=matrix[i].map(norm);
  const map={};for(const [field,names] of Object.entries(aliases))map[field]=heads.findIndex(h=>names.includes(h));
  if(map.tanggal>=0&&map.pasar>=0&&map.komoditas>=0&&map.harga>=0){headerIndex=i;mapping=map;break;}
 }
 const parsePrice=value=>{
  if(typeof value==='number')return value;
  const t=String(value??'').replace(/[^\d,.-]/g,'').trim();
  if(!t)return NaN;
  if(t.includes(',')&&t.includes('.'))return Number(t.lastIndexOf(',')>t.lastIndexOf('.')?t.replace(/\./g,'').replace(',','.'):t.replace(/,/g,''));
  if(t.includes(','))return Number(/,\d{1,2}$/.test(t)?t.replace(',','.'):t.replace(/,/g,''));
  return Number(t.replace(/\.(?=\d{3}(?:\.|$))/g,''));
 };
 if(headerIndex>=0){
  const records=[];let skipped=0;
  for(const line of matrix.slice(headerIndex+1)){
   const get=field=>mapping[field]<0?'':line[mapping[field]]??'';
   const r={tanggal:parseDate(get('tanggal')),pasar:String(get('pasar')).trim(),
    komoditas:String(get('komoditas')).trim().replace(/^-\s*/,''),satuan:String(get('satuan')).trim()||'Kg',
    harga:parsePrice(get('harga'))};
   if(r.tanggal&&r.pasar&&r.komoditas&&Number.isFinite(r.harga)&&r.harga>0)records.push(r);else skipped++;
  }
  if(!records.length)throw Error('Kolom dikenali, tetapi tidak ada harga valid. Periksa format tanggal dan angka.');
  return {records,skipped};
 }
 const sample=matrix.slice(0,5).map(r=>r.slice(0,8).join(' | ')).join(' / ').slice(0,300);
 throw Error('Format Google Sheets belum sesuai tabel data harian. Kolom wajib: Tanggal, Pasar, Komoditas, Harga (Satuan opsional). Contoh isi: '+sample);
}
function parseCSVMatrix(text){
 const sep=(()=>{
  const line=(text.split(/\r?\n/).find(x=>x.trim())||'');
  const count=char=>{let n=0,quoted=false;for(let i=0;i<line.length;i++){if(line[i]==='"'){if(quoted&&line[i+1]==='"')i++;else quoted=!quoted}else if(!quoted&&line[i]===char)n++}return n};
  return count(';')>count(',')?';':',';
 })();
 let result=[],row=[],field='',quoted=false;
 for(let i=0;i<text.length;i++){
  const c=text[i];
  if(c==='"'){if(quoted&&text[i+1]==='"'){field+='"';i++}else quoted=!quoted}
  else if(c===sep&&!quoted){row.push(field);field=''}
  else if((c==='\n'||c==='\r')&&!quoted){
   if(c==='\r'&&text[i+1]==='\n')i++;
   row.push(field);if(row.some(v=>String(v).trim()))result.push(row);
   row=[];field='';
  }else field+=c;
 }
 row.push(field);if(row.some(v=>String(v).trim()))result.push(row);
 return result;
}
function applySync(records,when,fromCache=false){
 mergeWithLocal(records);
 $('syncBadge').textContent=fromCache?'Data tersimpan':'Google Sheets aktif';
 $('syncUpdated').textContent='Terakhir berhasil: '+new Date(when).toLocaleString('id-ID');
 syncStatus((fromCache?'Memuat salinan sinkronisasi sebelumnya. ':'Sinkronisasi berhasil. ')+records.length.toLocaleString('id-ID')+' baris data Google Sheets digunakan.');
}

async function syncGoogleSheet(){
 if(syncBusy)return;
 syncBusy=true;$('syncNow').disabled=true;syncStatus('Mengambil data melalui server Netlify…');
 try{
  const controller=new AbortController();
  const timeout=setTimeout(()=>controller.abort(),25000);
  let response;
  try{response=await fetch('/.netlify/functions/sheet',{cache:'no-store',signal:controller.signal});}
  finally{clearTimeout(timeout)}
  const payload=await response.json().catch(()=>({error:'Respons server bukan JSON'}));
  if(!response.ok)throw Error(payload.error||'HTTP '+response.status);
  const {records,skipped}=validateSheet(payload.csv);
  const when=new Date().toISOString();
  applySync(records,when);
  $('syncBadge').textContent='Google Sheets aktif';
  syncStatus('Sinkronisasi berhasil: '+records.length.toLocaleString('id-ID')+' baris valid dari Google Sheets'+(skipped?' ('+skipped+' dilewati)':'')+'.');
  try{localStorage.setItem(SYNC_CACHE_KEY,JSON.stringify({records,when}));}catch(e){}
 }catch(e){
  syncStatus('Sinkronisasi belum berhasil: '+e.message+'. Data terakhir tetap tersedia. Periksa format dan akses sumber.',true);
  $('syncBadge').textContent='Mode cadangan';
 }finally{syncBusy=false;$('syncNow').disabled=false}
}
function configureSyncTimer(){
 if(syncTimer)clearInterval(syncTimer);
 const mins=Number($('syncInterval').value);
 try{localStorage.setItem('tuban_sync_interval',String(mins))}catch(e){}
 if(mins>0)syncTimer=setInterval(()=>{if(!document.hidden)syncGoogleSheet()},mins*60000);
}
$('syncNow').addEventListener('click',syncGoogleSheet);
$('syncImportCsv').addEventListener('click',async()=>{const f=$('syncCsvFile').files[0];if(!f){syncStatus('Pilih file CSV terlebih dahulu.',true);return;}try{const {records,skipped}=validateSheet(await f.text());const when=new Date().toISOString();applySync(records,when);$('syncBadge').textContent='CSV terbaru dimuat';if(skipped)syncStatus('CSV berhasil dimuat. '+skipped+' baris tidak valid dilewati.');try{localStorage.setItem(SYNC_CACHE_KEY,JSON.stringify({records,when}));}catch(e){} }catch(e){syncStatus('CSV gagal dimuat: '+e.message,true);}});
$('syncInterval').addEventListener('change',configureSyncTimer);
try{
 const old=JSON.parse(localStorage.getItem(SYNC_CACHE_KEY)||'null');
 if(old&&Array.isArray(old.records)&&old.records.length)applySync(old.records,old.when||new Date().toISOString(),true);
}catch(e){}
try{
 const saved=localStorage.getItem('tuban_sync_interval');
 if(saved!==null&&['0','5','10','15'].includes(saved))$('syncInterval').value=saved;
}catch(e){}
configureSyncTimer();
syncGoogleSheet();

