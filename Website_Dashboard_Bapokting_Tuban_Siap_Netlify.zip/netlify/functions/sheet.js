// Netlify Function: same-origin proxy for public Google Sheets CSV.
// No npm dependencies or secret credentials required for a public sheet.
const DOC_ID = '1m3e9cYb13aMrSNnj6pdUqgZe2iSGxKVywbPQUOUzhZQ';
const GID = '74546651';
const endpoints = [
  `https://docs.google.com/spreadsheets/d/${DOC_ID}/gviz/tq?tqx=out%3Acsv&gid=${GID}`,
  `https://docs.google.com/spreadsheets/d/${DOC_ID}/export?format=csv&gid=${GID}`
];
exports.handler = async () => {
  let failures = [];
  for (const url of endpoints) {
    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 12000);
      let res;
      try { res = await fetch(url, {signal: controller.signal, headers:{'User-Agent':'Mozilla/5.0 (compatible; TubanDashboard/1.0)'}}); }
      finally { clearTimeout(timeout); }
      if (!res.ok) throw new Error('HTTP '+res.status);
      const csv = await res.text();
      if (/^\s*<(?:!doctype|html)/i.test(csv) || !csv.trim()) throw new Error('Google mengembalikan HTML atau data kosong');
      if (csv.length > 20_000_000) throw new Error('CSV melebihi batas 20 MB');
      return {statusCode:200,headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'public, max-age=60, s-maxage=120'},
        body:JSON.stringify({csv,source:'google-sheets',retrievedAt:new Date().toISOString()})};
    } catch(e) { failures.push(e.message); }
  }
  return {statusCode:502,headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'},
    body:JSON.stringify({error:'Tidak dapat membaca CSV publik dari Google Sheets. '+failures.join('; ')})};
};
